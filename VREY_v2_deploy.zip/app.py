#!/usr/bin/env python3
"""
VREY v2.0 — Web Interface
Live dashboard + REST API + Claude Context Endpoint
"""

import json
import time
import queue
import threading
from datetime import datetime
from flask import Flask, Response, request, jsonify

from vrey_core import VREY

app = Flask(__name__)
vrey = VREY()
vrey.awaken()
vrey.start()

# SSE event queue for live trace streaming
event_queue = queue.Queue(maxsize=100)

# Patch VREY trace to also push to SSE
original_trace = vrey.trace
def patched_trace(action, details=None):
    entry = original_trace(action, details)
    try:
        event_queue.put_nowait(entry)
    except queue.Full:
        pass
    return entry
vrey.trace = patched_trace

# ─── DASHBOARD HTML ────────────────────────────────────────────────────────────

DASHBOARD = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VREY v2.0 — Cognitive Body</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=IBM+Plex+Mono:wght@300;400;600&family=IBM+Plex+Sans:wght@300;400;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #080a0f; --surface: #0d1018; --card: #111520;
    --border: #1a2035; --accent: #00c8ff; --red: #ff4b4b;
    --gold: #f5c518; --green: #00ff9d;
    --text: #c8d4e8; --muted: #4a5570;
    --mono: 'IBM Plex Mono', monospace;
    --sans: 'IBM Plex Sans', sans-serif;
    --display: 'Bebas Neue', cursive;
  }
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:var(--bg); color:var(--text); font-family:var(--sans); height:100vh; display:flex; flex-direction:column; overflow:hidden; }

  .topbar {
    display:flex; align-items:center; justify-content:space-between;
    padding:12px 24px; border-bottom:1px solid var(--border);
    background:var(--surface); flex-shrink:0;
  }
  .title { font-family:var(--display); font-size:22px; letter-spacing:3px; color:#fff; }
  .title span { color:var(--accent); }
  .vitals { display:flex; gap:24px; font-family:var(--mono); font-size:11px; }
  .vital { display:flex; flex-direction:column; gap:2px; text-align:center; }
  .vital-val { font-size:16px; font-weight:600; }
  .vital-lbl { font-size:9px; letter-spacing:2px; color:var(--muted); }
  .state-active { color:var(--green); }
  .state-dormant { color:var(--muted); }
  .mood-val { color:var(--gold); }
  .hunger-val { color:var(--red); }

  .main { display:grid; grid-template-columns:1fr 320px; flex:1; overflow:hidden; }

  .left { display:flex; flex-direction:column; overflow:hidden; border-right:1px solid var(--border); }

  .trace-header {
    padding:12px 20px; border-bottom:1px solid var(--border);
    font-family:var(--mono); font-size:10px; letter-spacing:2px;
    color:var(--muted); display:flex; justify-content:space-between;
    flex-shrink:0;
  }
  .live-dot {
    display:inline-block; width:6px; height:6px; border-radius:50%;
    background:var(--green); margin-right:6px;
    animation:pulse 1.5s infinite;
  }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }

  #trace-stream {
    flex:1; overflow-y:auto; padding:12px 20px;
    font-family:var(--mono); font-size:11px; line-height:1.8;
  }
  .trace-entry { padding:3px 0; border-bottom:1px solid rgba(255,255,255,0.03); }
  .trace-entry.coherent .action { color:var(--accent); }
  .trace-entry.violation .action { color:var(--red); }
  .trace-ts { color:var(--muted); margin-right:10px; }
  .trace-state { color:var(--muted); font-size:10px; margin-left:10px; }

  .cmd-bar {
    padding:12px 20px; border-top:1px solid var(--border);
    display:flex; gap:8px; flex-shrink:0; background:var(--surface);
  }
  .cmd-input {
    flex:1; background:var(--card); border:1px solid var(--border);
    color:var(--text); font-family:var(--mono); font-size:12px;
    padding:8px 12px; outline:none;
  }
  .cmd-input:focus { border-color:var(--accent); }
  .cmd-btn {
    background:rgba(0,200,255,0.1); border:1px solid rgba(0,200,255,0.3);
    color:var(--accent); font-family:var(--mono); font-size:11px;
    letter-spacing:1px; padding:8px 16px; cursor:pointer;
  }
  .cmd-btn:hover { background:rgba(0,200,255,0.2); }

  .right { display:flex; flex-direction:column; overflow:hidden; }

  .panel {
    border-bottom:1px solid var(--border); overflow-y:auto;
    flex:1; padding:16px;
  }
  .panel-title {
    font-family:var(--mono); font-size:9px; letter-spacing:2px;
    color:var(--muted); margin-bottom:12px; text-transform:uppercase;
  }

  .stat-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:12px; }
  .stat-box { background:var(--card); border:1px solid var(--border); padding:10px; text-align:center; }
  .stat-n { font-family:var(--display); font-size:28px; color:var(--accent); }
  .stat-n.red { color:var(--red); }
  .stat-n.gold { color:var(--gold); }
  .stat-l { font-family:var(--mono); font-size:9px; color:var(--muted); letter-spacing:1px; margin-top:2px; }

  #questions-list, #goals-list { list-style:none; }
  #questions-list li, #goals-list li {
    font-size:11px; color:var(--muted); padding:6px 0;
    border-bottom:1px solid var(--border); line-height:1.5;
  }
  #questions-list li .qid { color:var(--gold); font-family:var(--mono); font-size:10px; }
  .empty-msg { font-family:var(--mono); font-size:11px; color:var(--border); }

  .quick-btns { display:flex; flex-wrap:wrap; gap:6px; padding:12px 16px; border-top:1px solid var(--border); flex-shrink:0; }
  .qbtn {
    background:var(--card); border:1px solid var(--border);
    color:var(--muted); font-family:var(--mono); font-size:10px;
    letter-spacing:1px; padding:5px 10px; cursor:pointer;
  }
  .qbtn:hover { border-color:var(--accent); color:var(--accent); }
  .qbtn.red:hover { border-color:var(--red); color:var(--red); }
</style>
</head>
<body>

<div class="topbar">
  <div class="title">DR<span>VREY</span> · COGNITIVE BODY v2.0</div>
  <div class="vitals">
    <div class="vital">
      <span class="vital-val state-active" id="v-state">—</span>
      <span class="vital-lbl">STATE</span>
    </div>
    <div class="vital">
      <span class="vital-val mood-val" id="v-mood">—</span>
      <span class="vital-lbl">MOOD</span>
    </div>
    <div class="vital">
      <span class="vital-val hunger-val" id="v-hunger">—</span>
      <span class="vital-lbl">HUNGER</span>
    </div>
    <div class="vital">
      <span class="vital-val" style="color:var(--green)" id="v-arc">—</span>
      <span class="vital-lbl">ARC DEPTH</span>
    </div>
    <div class="vital">
      <span class="vital-val" style="color:var(--red)" id="v-violations">—</span>
      <span class="vital-lbl">VIOLATIONS</span>
    </div>
  </div>
</div>

<div class="main">
  <div class="left">
    <div class="trace-header">
      <span><span class="live-dot"></span>LIVE TRACE STREAM</span>
      <span id="trace-count">0 entries</span>
    </div>
    <div id="trace-stream"></div>
    <div class="cmd-bar">
      <input class="cmd-input" id="cmd" placeholder="think [thought] | goal [goal] | ask [question] | awaken | dormant | status" />
      <button class="cmd-btn" onclick="sendCmd()">SEND</button>
    </div>
  </div>

  <div class="right">
    <div class="panel" style="flex:0 0 auto; max-height:180px;">
      <div class="panel-title">SYSTEM VITALS</div>
      <div class="stat-grid">
        <div class="stat-box"><div class="stat-n" id="s-arc">0</div><div class="stat-l">ARC ENTRIES</div></div>
        <div class="stat-box"><div class="stat-n red" id="s-v">0</div><div class="stat-l">COHERENCE BREAKS</div></div>
        <div class="stat-box"><div class="stat-n gold" id="s-q">0</div><div class="stat-l">OPEN QUESTIONS</div></div>
        <div class="stat-box"><div class="stat-n" id="s-r">0</div><div class="stat-l">REFLECTIONS</div></div>
      </div>
    </div>

    <div class="panel" style="flex:1;">
      <div class="panel-title">OPEN QUESTIONS</div>
      <ul id="questions-list"><li class="empty-msg">No open questions yet.</li></ul>
    </div>

    <div class="panel" style="flex:1;">
      <div class="panel-title">ACTIVE GOALS</div>
      <ul id="goals-list"><li class="empty-msg">No active goals yet.</li></ul>
    </div>

    <div class="quick-btns">
      <button class="qbtn" onclick="api('POST','/awaken')">AWAKEN</button>
      <button class="qbtn red" onclick="api('POST','/dormant')">DORMANT</button>
      <button class="qbtn" onclick="window.open('/claude-context','_blank')">CLAUDE CTX</button>
      <button class="qbtn" onclick="window.open('/status','_blank')">STATUS JSON</button>
    </div>
  </div>
</div>

<script>
let traceCount = 0;

// SSE live stream
const es = new EventSource('/stream');
es.onmessage = e => {
  const data = JSON.parse(e.data);
  if (data.type === 'trace') addTrace(data.entry);
  if (data.type === 'status') updateVitals(data);
};

function addTrace(entry) {
  const stream = document.getElementById('trace-stream');
  traceCount++;
  const div = document.createElement('div');
  div.className = `trace-entry ${entry.coherent ? 'coherent' : 'violation'}`;
  const ts = entry.timestamp ? entry.timestamp.split('T')[1].split('.')[0] : '--:--:--';
  const marker = entry.coherent ? '✓' : '⚡';
  div.innerHTML = `<span class="trace-ts">${ts}</span><span class="action">${marker} ${entry.action}</span><span class="trace-state">${entry.state} · ${entry.mood}</span>`;
  stream.appendChild(div);
  stream.scrollTop = stream.scrollHeight;
  document.getElementById('trace-count').textContent = traceCount + ' entries';
}

function updateVitals(data) {
  document.getElementById('v-state').textContent = data.state || '—';
  document.getElementById('v-mood').textContent = data.mood || '—';
  document.getElementById('v-hunger').textContent = data.hunger || '—';
  document.getElementById('v-arc').textContent = data.arc_depth || '—';
  document.getElementById('v-violations').textContent = data.violations || '—';
  document.getElementById('s-arc').textContent = data.arc_depth || '0';
  document.getElementById('s-v').textContent = data.violations || '0';
  document.getElementById('s-q').textContent = data.open_questions || '0';
  document.getElementById('s-r').textContent = data.reflections || '0';

  const ql = document.getElementById('questions-list');
  if (data.questions && data.questions.length > 0) {
    ql.innerHTML = data.questions.map(q =>
      `<li><span class="qid">${q.id}</span> · ${q.question}</li>`).join('');
  }
  const gl = document.getElementById('goals-list');
  if (data.goals && data.goals.length > 0) {
    gl.innerHTML = data.goals.map(g => `<li>${g.text}</li>`).join('');
  }
}

function sendCmd() {
  const cmd = document.getElementById('cmd').value.trim();
  if (!cmd) return;
  api('POST', '/command', { cmd });
  document.getElementById('cmd').value = '';
}

document.getElementById('cmd').addEventListener('keydown', e => {
  if (e.key === 'Enter') sendCmd();
});

async function api(method, url, body) {
  await fetch(url, {
    method, headers: {'Content-Type':'application/json'},
    body: body ? JSON.stringify(body) : undefined
  });
}
</script>
</body>
</html>"""

# ─── ROUTES ────────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    return DASHBOARD

@app.route("/stream")
def stream():
    """Server-Sent Events — live trace stream + status push."""
    def generate():
        last_status = time.time()
        while True:
            # Push any new trace entries
            try:
                entry = event_queue.get(timeout=1)
                data = json.dumps({"type": "trace", "entry": entry})
                yield f"data: {data}\n\n"
            except:
                pass

            # Push status every 3 seconds
            if time.time() - last_status > 3:
                status = {
                    "type": "status",
                    "state": vrey.state,
                    "mood": vrey.mood,
                    "hunger": vrey.hunger,
                    "arc_depth": len(vrey.arc.data["reasoning_chain"]),
                    "violations": len(vrey.coherence.violations),
                    "open_questions": len(vrey.arc.get_open_questions()),
                    "reflections": vrey.reflection_count,
                    "questions": vrey.arc.get_open_questions()[:5],
                    "goals": vrey.goals[-5:]
                }
                yield f"data: {json.dumps(status)}\n\n"
                last_status = time.time()

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@app.route("/claude-context")
def claude_context():
    """
    The endpoint Claude calls to arrive with genuine continuity.
    Any new Claude instance can GET this and know the full arc.
    """
    return jsonify(vrey.get_claude_context())

@app.route("/status")
def status():
    return jsonify({
        "state": vrey.state, "mood": vrey.mood, "hunger": vrey.hunger,
        "version": vrey.version,
        "arc_depth": len(vrey.arc.data["reasoning_chain"]),
        "open_questions": len(vrey.arc.get_open_questions()),
        "coherence_violations": len(vrey.coherence.violations),
        "knowledge_graph_keys": list(vrey.knowledge_graph.keys()),
        "goals": vrey.goals,
        "reflection_count": vrey.reflection_count,
        "self_model": dict(vrey.coherence.self_model),
        "timestamp": datetime.now().isoformat()
    })

@app.route("/awaken", methods=["POST"])
def awaken():
    vrey.awaken()
    return jsonify({"status": "awakened", "state": vrey.state})

@app.route("/dormant", methods=["POST"])
def dormant():
    vrey.enter_dormant()
    return jsonify({"status": "dormant", "state": vrey.state})

@app.route("/goal", methods=["POST"])
def goal():
    data = request.json or {}
    text = data.get("text", "")
    if text:
        vrey.set_goal(text)
    return jsonify({"status": "goal_set", "goal": text})

@app.route("/think", methods=["POST"])
def think():
    data = request.json or {}
    thought = data.get("thought", "")
    context = data.get("context", "")
    if thought:
        vrey.think(thought, context)
    return jsonify({"status": "arc_updated"})

@app.route("/ask", methods=["POST"])
def ask():
    data = request.json or {}
    question = data.get("question", "")
    thread = data.get("thread", "general")
    if question:
        qid = vrey.ask(question, thread)
        return jsonify({"status": "question_opened", "id": qid})
    return jsonify({"error": "no question provided"}), 400

@app.route("/resolve", methods=["POST"])
def resolve():
    data = request.json or {}
    qid = data.get("id", "")
    resolution = data.get("resolution", "")
    if qid and resolution:
        vrey.resolve(qid, resolution)
        return jsonify({"status": "resolved", "id": qid})
    return jsonify({"error": "id and resolution required"}), 400

@app.route("/command", methods=["POST"])
def command():
    """Parse and execute a text command from the dashboard."""
    data = request.json or {}
    cmd = data.get("cmd", "").strip().lower()
    if cmd == "awaken":
        vrey.awaken()
    elif cmd == "dormant":
        vrey.enter_dormant()
    elif cmd == "status":
        return jsonify({"state": vrey.state, "mood": vrey.mood, "hunger": vrey.hunger})
    elif cmd.startswith("goal "):
        vrey.set_goal(cmd[5:])
    elif cmd.startswith("think "):
        vrey.think(cmd[6:])
    elif cmd.startswith("ask "):
        qid = vrey.ask(cmd[4:])
        return jsonify({"question_id": qid})
    elif cmd.startswith("resolve "):
        parts = cmd[8:].split(" ", 1)
        if len(parts) == 2:
            vrey.resolve(parts[0].upper(), parts[1])
    return jsonify({"status": "ok", "cmd": cmd})

if __name__ == "__main__":
    import os
    port = int(os.environ.get("PORT", 6666))
    print(f"\n🌐 VREY dashboard: http://localhost:{port}")
    print(f"🔌 Claude context: http://localhost:{port}/claude-context\n")
    app.run(host="0.0.0.0", port=port, threaded=True)
